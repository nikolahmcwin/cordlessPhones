/ * Read Me for E8 Cordless Phones */

1. Use Python 3
2. Run phones.py, 
3. Pass input from a file via stdin 
4. The range found will be output as the radius of the circle found (in metres)

Note1: kdtree.py is a library used via https://pypi.org/project/kdtree/ however, we have made 3 minor edits to cast values returned. These edits are commented and dated to when we edited them.

Note2: smallestcircle.py is a library used via https://github.com/nayuki/Nayuki-web-published-code/blob/master/smallest-enclosing-circle/smallestenclosingcircle.py we have not edited nor changed any of the code.

Thank you to both authors for your excellent code.